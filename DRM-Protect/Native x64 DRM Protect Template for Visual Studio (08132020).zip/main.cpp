/*Uncomment one of the two below to select protection vendor*/
//#define DRM_PROTECTION_VMP
//#define DRM_PROTECTION_THEMIDA

#include "predefined.h"

int main()
{
	return 0;
}