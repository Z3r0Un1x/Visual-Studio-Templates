#ifndef __predefined_h__
#define __predefined_h__
#pragma once

#ifdef DRM_PROTECTION_VMP
#include "VMProtect/3.4.0 (build 1150)/Include/C/VMProtectSDK.h"
#pragma comment(lib, "VMProtectSDK64.lib")

#ifdef UNICODE
#define VMProtectStr(x) VMProtectDecryptStringW(L##x)
#else
#define VMProtectStr(x) VMProtectDecryptStringA(#x)
#endif
#define VMPVirtualize(mark) VMProtectBeginVirtualization(#mark)
#define VMPMutate(mark) VMProtectBeginMutation(#mark)
#define VMPUltra(mark) VMProtectBeginUltra(#mark)
#define VMPEnd VMProtectEnd()

#endif // DRM_PROTECTION_VMP

#ifdef DRM_PROTECTION_THEMIDA
#include "Themida/3.0.4.0/Include/C/ThemidaSDK.h"
#pragma comment(lib, "SecureEngineSDK64.lib")
#endif // DRM_PROTECTION_THEMIDA


#endif
